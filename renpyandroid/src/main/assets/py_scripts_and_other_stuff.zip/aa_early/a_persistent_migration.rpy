init -999 python:
    import renpy.store as store
    import renpy.exports as renpy
    import renpy.object as renpy_object
    import renpy.game as renpy_game
    import renpy.persistent as renpy_persistent_module
    import os
    import cPickle as pickle
    import zlib
    import collections
    import struct
    import binascii
    import base64
    import time
    import datetime
    
    try:
        import builtins
    except ImportError:
        import __builtin__ as builtins

    # These must be at module level for pickle to find them (at least initially)
    # They are used to spoof Ren'Py 6.99 compatible objects

    class CleanPersistent(object):
        """Spoofs renpy.persistent.Persistent"""
        def __setstate__(self, state):
            self.__dict__.update(state)
        def __getstate__(self):
            return self.__dict__

    class CleanNamespace(object):
        """Spoofs renpy.object.Object for generic containers"""
        def __setstate__(self, state):
            self.__dict__.update(state)
        def __getstate__(self):
            return self.__dict__
        def __repr__(self):
            return "<CleanNamespace %s>" % self.__dict__.keys()

    # Configure the spoofing metadata
    CleanPersistent.__module__ = "renpy.persistent"
    CleanPersistent.__name__ = "Persistent"

    CleanNamespace.__module__ = "renpy.object"
    CleanNamespace.__name__ = "Object"

    class CleanPreferences(object):
        """Spoofs renpy.preferences.Preferences"""
        def __setstate__(self, state):
            self.__dict__.update(state)
        def __getstate__(self):
            return self.__dict__
    
    CleanPreferences.__module__ = "renpy.preferences"
    CleanPreferences.__name__ = "Preferences"

    def _hybrid_migration():
        """
        A robust persistent data migration system for Ren'Py 6.99 (py2).
        This script modifies the live 'store.persistent' object and uses the
        standard renpy.save_persistent() function. It includes logic,
        such as the one-time execution marker and specific handling for the
        _mas_affection attribute's dictionary structure.
        """
        import os
        import pickle
        import zlib
        import time
        import binascii
        import struct
        import base64
        import collections
        old_persistent_path = os.path.join(renpy.config.savedir, "persistent")
        migrated_marker_path = os.path.join(renpy.config.savedir, "persistent.migrated")

        # This block only runs if we haven't migrated the old persistent file yet
        if not os.path.exists(migrated_marker_path) and os.path.exists(old_persistent_path):
            print "Persistent Migration: Starting one-time migration from old persistent."
            
            old_persistent = None
            try:
                with open(old_persistent_path, 'rb') as f:
                    old_persistent = pickle.loads(zlib.decompress(f.read()))
            except Exception as e:
                print "Persistent Migration: Error loading old 'persistent' file: %s" % e
                try:
                    os.rename(old_persistent_path, old_persistent_path + ".corrupt")
                except Exception:
                    pass
            
            if old_persistent:
                try:
                    migrated_count = 0
                    EXCLUDED_ATTRIBUTES = {
                        '_version', '_renpy_version', '_save_game_slots', '_location',
                        '_game_menu_screen', '_main_menu_screen',
                    }
        
                    for attr in dir(old_persistent):
                        if attr.startswith('__') or attr in EXCLUDED_ATTRIBUTES or callable(getattr(old_persistent, attr)):
                            continue
                        
                        try:
                            value = getattr(old_persistent, attr)
                            
                            if attr == '_mas_affection':
                                final_value = value
                            else:
                                final_value = value
                            
                            setattr(store.persistent, attr, final_value)
                            migrated_count += 1
                        except Exception as e:
                            print "Persistent Migration: Could not migrate attribute '%s': %s" % (attr, e)
        
                    renpy.save_persistent()
                    
                    if not hasattr(store.persistent, "_mas_affection_version"):
                        store.persistent._mas_affection_version = 0
        
                    # Check if we need to migrate V1 -> V2
                    if store.persistent._mas_affection_version < 2:
                        print "Persistent Migration: Detected old Affection V1 data. Attempting V2 migration..."
                        try:
                            old_aff_data = getattr(store.persistent, "_mas_affection", {})
                            print ">> DEBUG MIG V1_DATA_TYPE:", type(old_aff_data)
                            print ">> DEBUG MIG V1_DATA_REPR:", repr(old_aff_data)
                            if hasattr(old_aff_data, '__dict__'):
                                print ">> DEBUG MIG V1_DATA_DICT:", repr(old_aff_data.__dict__)
                                
                            if old_aff_data is not None:
                                # Initialize defaults
                                aff = 0.0
                                today_exp = 0.0
                                freeze_ts = time.time()
                                apologyflag = False
                                
                                def _parse_to_int_float(val, name="unknown"):
                                    try:
                                        if val is None:
                                            print ">> DEBUG MIG PARSE: %s is None -> 0.0" % name
                                            return 0.0
                                        res = float(int(float(val)))
                                        print ">> DEBUG MIG PARSE SUCCESS: %s -> %s -> %s" % (name, repr(val), repr(res))
                                        return res
                                    except Exception as e:
                                        print ">> DEBUG MIG PARSE ERROR (%s): %s on value %s" % (name, repr(e), repr(val))
                                        return 0.0

                                print ">> DEBUG MIG PARSING LOGIC START"
                                if isinstance(old_aff_data, dict):
                                    print ">> DEBUG MIG BRANCH: dict"
                                    aff = _parse_to_int_float(old_aff_data.get("affection", 0.0), "dict.affection")
                                    today_exp = _parse_to_int_float(old_aff_data.get("today_exp", 0.0), "dict.today_exp")
                                    freeze_date = old_aff_data.get("freeze_date", None)
                                    apologyflag = old_aff_data.get("apologyflag", False)
                                elif hasattr(old_aff_data, 'affection'):
                                    print ">> DEBUG MIG BRANCH: object with 'affection' attr"
                                    aff = _parse_to_int_float(getattr(old_aff_data, 'affection', 0.0), "obj.affection")
                                    today_exp = _parse_to_int_float(getattr(old_aff_data, 'today_exp', 0.0), "obj.today_exp")
                                    freeze_date = getattr(old_aff_data, 'freeze_date', None)
                                    apologyflag = getattr(old_aff_data, 'apologyflag', False)
                                else:
                                    print ">> DEBUG MIG BRANCH: fallback scalar"
                                    aff = _parse_to_int_float(old_aff_data, "scalar")
                                    
                                if freeze_date is not None:
                                    try:
                                        # Handle datetime object
                                        freeze_ts = time.mktime(freeze_date.timetuple())
                                    except Exception as e:
                                        print ">> DEBUG MIG DATE PARSING ERR:", repr(e)
                                
                                if aff >= 1000000:
                                    aff = 0.0
                                
                                # Construct V2 Tuple
                                v2_data = (
                                    aff, 0.0, today_exp, 0.0, float(freeze_ts), time.time(), 7.0
                                )
                                
                                # Pack and Encode
                                packed_data = struct.pack("!d d d d d d d", *v2_data)
                                hex_data = binascii.hexlify(packed_data)
                                b64_data = base64.b64encode(hex_data)
                                
                                # Update Persistent
                                store.persistent._mas_affection_data = b64_data
                                store.persistent._mas_affection_should_apologise = apologyflag
                                store.persistent._mas_affection = collections.defaultdict(float)
                                store.persistent._mas_affection_version = 2
                                store.persistent._mas_v2_migration_done = True
                                
                                # Set runtime backup to prevent script-affection.rpy from
                                # thinking the data was corrupted and wiping it with get_default_data()
                                try:
                                    if hasattr(store, 'mas_affection'):
                                        store.mas_affection._m1_script0x2daffection__runtime_backup = b64_data
                                except Exception:
                                    pass
                                
                                print "Persistent Migration: Successfully migrated Affection V1 -> V2 (with b64_data %s)." % str(b64_data)[:20]
                                renpy.save_persistent()
                                
                        except Exception as e:
                            print "Persistent Migration: Affection V1 -> V2 migration failed: %s" % e
                    
                    # Mark strictly as done
                    try:
                        with open(migrated_marker_path, 'w') as f:
                            f.write("migrated")
                        print "Persistent Migration: One-time migration completed for %d attributes." % migrated_count
                    except Exception as e:
                        print "Persistent Migration: Failed to create marker file: %s" % e

                except Exception as e:
                    print "Persistent Migration: A critical error occurred during one-time migration: %s" % e

        # This runs every time _hybrid_migration() is called
        print "Persistent Migration: Sanitizing persistent data for 6.99 compatibility..."
        sanitized_count = 0
        
        # Prepare patches for pickle
        original_persistent_cls = getattr(renpy_persistent_module, "Persistent", None)
        original_object_cls = getattr(renpy_object, "Object", None)
        
        # Prepare the object
        new_persistent = CleanPersistent()

        # Ren'Py 7.8.4 aliases 'list' to 'future.types.newlist', etc
        # We need to find the actual __builtin__.list to avoid ImportError in 6.99
        RealList = list
        RealDict = dict
        RealSet = set
        
        try:
            # We look for a base class that is strictly 'list'/'dict'/'set'
            # and seemingly not from the 'future' module
            for base in list.__mro__:
                module_name = str(getattr(base, '__module__', ''))
                type_name = base.__name__
                if type_name == 'list' and "future" not in module_name and "renpy" not in module_name:
                    RealList = base
                    break
            
            for base in dict.__mro__:
                module_name = str(getattr(base, '__module__', ''))
                type_name = base.__name__
                if type_name == 'dict' and "future" not in module_name and "renpy" not in module_name:
                    RealDict = base
                    break
            
            for base in set.__mro__:
                module_name = str(getattr(base, '__module__', ''))
                type_name = base.__name__
                if type_name == 'set' and "future" not in module_name and "renpy" not in module_name:
                    RealSet = base
                    break

        except Exception as e:
            print "Persistent Migration: Warning - Failed to recover native types via MRO: %s" % e

        # Recursive Sanitizer with Memoization
        memo = {}

        def _make_native(obj, path="root"):
            """
            Recursively convert everything to native Python types.
            Traverses lists, dicts, sets, tuples, and object.__dict__.
            """
            # Handle Primitives (Pass-through)
            # Add datetime objects to primitives because they are safe to pickle across versions
            # and we do not want to convert them to generic Objects
            import datetime
            if obj is None or isinstance(obj, (int, float, bool, basestring, 
                    datetime.date, datetime.time, datetime.datetime, datetime.timedelta)):
                return obj
            
            # Handle Cycles
            obj_id = id(obj)
            if obj_id in memo:
                return memo[obj_id]
            
            # Handle Collections (Convert to real native builtins)
            
            # Helper for explicit type checking by string to catch Revertable aliases
            type_str = str(type(obj))
            
            # List / RevertableList
            if "List" in type_str or "list" in type_str or isinstance(obj, list):
                # Double check it's list-like
                if hasattr(obj, '__iter__') and not isinstance(obj, (dict, set, tuple, basestring)):
                    new_list = RealList()
                    memo[obj_id] = new_list # Register before recursion
                    for i, item in enumerate(obj):
                        new_path = "%s[%d]" % (path, i)
                        new_list.append(_make_native(item, new_path))
                    return new_list
            
            # Dict / RevertableDict
            is_dict_check = isinstance(obj, dict)

            if "Dict" in type_str or "dict" in type_str or is_dict_check:
                if hasattr(obj, 'items'):
                    new_dict = RealDict()
                    memo[obj_id] = new_dict # Register before recursion
                        
                    for k, v in obj.items():
                        # Key path is hard to represent if key is object, use repr
                        key_repr = str(k)
                        if len(key_repr) > 20: key_repr = key_repr[:17] + "..."
                        new_path = "%s[%s]" % (path, key_repr)
                        new_dict[_make_native(k, "%s.key" % new_path)] = _make_native(v, new_path)
                    return new_dict
            
            # Set / RevertableSet
            if "Set" in type_str or "set" in type_str or isinstance(obj, set):
                if hasattr(obj, '__iter__') and not isinstance(obj, (dict, list, tuple, basestring)):
                    new_set = RealSet()
                    memo[obj_id] = new_set # Register before recursion
                    for item in obj:
                        new_set.add(_make_native(item, "%s.{set_item}" % path))
                    return new_set
            
            # Tuple
            if "Tuple" in type_str or "tuple" in type_str or isinstance(obj, tuple):
                return builtins.tuple(_make_native(i, "%s[%d]" % (path, idx)) for idx, i in enumerate(obj))
            
            # Deque (convert to list for compatibility)
            import collections
            if "deque" in type_str or isinstance(obj, collections.deque):
                new_list = RealList()
                memo[obj_id] = new_list
                for i, item in enumerate(obj):
                    new_path = "%s[%d]" % (path, i)
                    new_list.append(_make_native(item, new_path))
                return new_list

            # Handle Objects (Generic & Ren'Py Objects)
            obj_type_str = str(type(obj))
            
            # Decide on the target container
            new_obj = None
            if "Preferences" in obj_type_str and "renpy.preferences" in obj_type_str:
                new_obj = CleanPreferences()
            else:
                new_obj = CleanNamespace()
            
            memo[obj_id] = new_obj # Register before recursion
            
            attributes = {}
            
            # Check __dict__
            if hasattr(obj, "__dict__"):
                for k, v in obj.__dict__.items():
                    attributes[k] = v
                    
            # Check __slots__
            if hasattr(obj, "__slots__"):
                for k in obj.__slots__:
                    if hasattr(obj, k):
                        attributes[k] = getattr(obj, k)
            
            try:
                for k in dir(obj):
                    if k in attributes: continue # Already got it
                    if k.startswith("__"): continue # Skip magic methods...
                    if k.startswith("_renpy"): continue # Skip renpy internals
                    
                    try:
                        v = getattr(obj, k)
                        if callable(v): continue # Skip methods
                        attributes[k] = v
                    except Exception:
                        pass
            except Exception:
                pass

            if not attributes:
                lower_type = type_str.lower()
                if "renpy" in lower_type or "store" in lower_type or "revertable" in lower_type:
                    print "Persistent Migration: Warning - Stripped opaque object '%s' at %s to empty namespace." % (type_str, path)
                    return new_obj
                
                return obj

            for k, v in attributes.items():
                if k.startswith('__') or callable(v):
                    continue
                if k.startswith("_renpy"): 
                    continue
                
                new_path = "%s.%s" % (path, k)
                clean_k = _make_native(k, path + ".key_name") # Keys are usually strings
                clean_v = _make_native(v, new_path)
                setattr(new_obj, clean_k, clean_v)
            
            return new_obj

        current_persistent_dict = store.persistent.__dict__

        # Do the aggressive sanitization
        try:
            print "Persistent Migration: Starting recursive sanitization..."
            
            # Transfer all attributes from current persistent to the new clean one
            for k, v in current_persistent_dict.items():
                if k.startswith("__") or k.startswith("_renpy"):
                    continue
                
                # Sanitize value
                clean_val = _make_native(v, "persistent.%s" % k)
                
                # Set on new persistent object
                setattr(new_persistent, k, clean_val)
                
            # Post-convertion check
            # Verify if Revertable types slipped through
            def verify_clean(obj, path="root", seen=None):
                if seen is None:
                    seen = set()
                
                if obj is None or isinstance(obj, (int, float, bool, basestring)): 
                    return
                
                # Check for cycles
                obj_id = id(obj)
                if obj_id in seen:
                    return
                seen.add(obj_id)
                
                type_str = str(type(obj))
                if "Revertable" in type_str:
                    print "Persistent Migration Critical Error: Found %s at %s after sanitization!" % (type_str, path)
                
                if isinstance(obj, (list, tuple)):
                    for i, x in enumerate(obj): 
                        verify_clean(x, "%s[%d]" % (path, i), seen)
                elif isinstance(obj, dict):
                    for k, v in obj.items():
                        verify_clean(k, "%s.key" % path, seen)
                        # Truncate key string for readability in path
                        k_str = str(k)
                        if len(k_str) > 20: k_str = k_str[:17] + "..."
                        verify_clean(v, "%s[%s]" % (path, k_str), seen)
                elif hasattr(obj, "__dict__"):
                    for k, v in obj.__dict__.items(): 
                        verify_clean(v, "%s.%s" % (path, k), seen)
            
            verify_clean(new_persistent, "persistent_699")

        except Exception as e:
            print "Persistent Migration: Error during sanitization: %s" % e
            import traceback
            traceback.print_exc()

        # Save the sanitized object to a separate file
        compat_persistent_path = os.path.join(renpy.config.savedir, "persistent_699")
        save_path = compat_persistent_path 
        
        try:
            # Import preferences module to patch it
            import renpy.preferences as renpy_preferences_module
            original_preferences_cls = getattr(renpy_preferences_module, "Preferences", None)
            
            if not original_preferences_cls:
                import sys
                p_module = sys.modules.get("renpy.preferences")
                if p_module:
                    original_preferences_cls = getattr(p_module, "Preferences", None)
                    if original_preferences_cls:
                        renpy_preferences_module = p_module

            # Temporarily replace the classes in the modules to spoof persistent names
            if original_persistent_cls:
                renpy_persistent_module.Persistent = CleanPersistent
            if original_object_cls:
                renpy_object.Object = CleanNamespace
            if original_preferences_cls:
                renpy_preferences_module.Preferences = CleanPreferences
            
            try:
                # compress & save
                import zlib
                
                # Pickle it
                p_bytes = pickle.dumps(new_persistent, protocol=2)
                
                check_terms = ["revertable", "Revertable", "future.types"]
                
                for term in check_terms:
                    if term in p_bytes:
                        print "Persistent Migration Fail: The pickle stream contains '%s'!" % term
                        
                        # Find and print context
                        start = p_bytes.find(term)
                        s_idx = max(0, start - 100)
                        e_idx = min(len(p_bytes), start + 100)
                        context = p_bytes[s_idx:e_idx]
                        print "Persistent Migration Debug: Context: %r" % context

                # Compress
                cdata = zlib.compress(p_bytes)
                
                # Write to file
                with open(save_path, "wb") as f:
                    f.write(cdata)
                
                print "Persistent Migration: Successfully saved 6.99-compatible persistent data to '%s'" % save_path
                
            except Exception as e:
                print "Persistent Migration: Failed to save compatible persistent file: %s" % e
            
            finally:
                # Restore the original classes
                if original_persistent_cls:
                    renpy_persistent_module.Persistent = original_persistent_cls
                if original_object_cls:
                    renpy_object.Object = original_object_cls
                if original_preferences_cls:
                    renpy_preferences_module.Preferences = original_preferences_cls

        except Exception as e:
            print "Persistent Migration: Critical error during class patching: %s" % e

        # Save the normal persistent for 7.8.4 as well (standard save)
        renpy.save_persistent()

    _hybrid_migration()
